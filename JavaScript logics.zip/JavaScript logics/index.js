/* Chapter 1:Alert */
alert("Welcome to the Javascript Logic App!");

/* chapter 2-3 Variables for Numbers and Strings */
let userName = prompt("What is your Name?");
console.log(userName);
let userAge = prompt("What is your age?");
console.log(userAge);
/* Chapter 4 Legal/illegal variable Name */
let fullName = userName;
/* let1name=illegal */

/*  Chapter 5-6 Math Expressions */
alert("your next year age")
let nextYearAge = Number(userAge) + 1;
console.log(nextYearAge);

/* Chapter 7 Concatenating Text Strings */
let greeting = "hey," + fullName + "!";

/* Chapter 8 Prompt */


/* Chapter 9 If Statements */
if (userAge > 0) {
    alert("Glad to know your Age!");
}

/* Chapter 10-11 Comparison and if....else */
if (userAge >= 18) {
    alert("you are an adult.");
} else {
    alert("you are not an adult.");
}

/* Chapter 12 Testing Sets Of Conditions */
if (userAge > 12 && userAge < 20) {
    alert("ah, a teenager!");
}

/* Chapter 13 Nested if */
if (userAge > 0) {
    if (userAge < 100) {
        alert("you are in a healthy range!");
    }
}

/* Chapter 13 Arrays and Manipulations */
let hobbies = ["reading", "writing", "coding", "designing"];
hobbies.push(prompt("What's your favourite hobby?"));
hobbies.splice(1, 0, "travelling");
let topHobbies = hobbies.slice(0, 2);

/* Chapter 17 For Loop */
for (let i = 0; i < hobbies.length; i++) {
    console.log("Hobby:", hobbies[i]);
}

/* Chapter 18 Flags and Breaks */
let foundCoding = false;
for (let i = 0; i < hobbies.length; i++) {
    if (hobbies[i] === "coding") {
        foundCoding = true;
        break;
    }
}

if (foundCoding) alert("you love coding too!");

/* Chapter 19 Nested Loops */
let numbers = [[1, 2], [3, 4]];
for (let i = 0; i < numbers.length; i++) {
    for (let j = 0; j < numbers[i].length; j++) {
        console.log("Nested numbers:", numbers[i[j]]);
    }
}

/* Chapter 20 Changing Case */
let lowerName = fullName.toLowerCase();
let upperName = fullName.toUpperCase();

/* Chapter 21 -24 Strings  and its Methods */
let charCount = fullName.length;
var firstChar = fullName.charAt(0);
var fixedName = fullName.replace("bad", "good");
let namePart = fullName.slice(0, 3);

/* chapter 25 rounding Numbers  */
let perciseAge = 25.33;
let rounded = Math.round(perciseAge);

/* Chapter 26 Random Numbers */
let luckyNumber = Math.floor(Math.random() * 100) + 1;
alert("your lucky number is: +luckyNumber");

/* chapter 27-28Converting strings?Numbers */
var ageString = String(userAge);
let ageInt = parseINT(ageString);
let ageFloat = parseFLoat(ageString);

/* Final Greeetings  */
alert('${greeting} Next year, you will be ${nextYearAge}.your fisrt hobby is ${hobbies[0}. your name in all caps:$ {upperNmae}. Luckynumber: ${luckyNumber}');